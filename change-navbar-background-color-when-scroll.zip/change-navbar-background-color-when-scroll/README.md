# change navbar background color when scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/Abdel-fattah/pen/gMXOaZ](https://codepen.io/Abdel-fattah/pen/gMXOaZ).

